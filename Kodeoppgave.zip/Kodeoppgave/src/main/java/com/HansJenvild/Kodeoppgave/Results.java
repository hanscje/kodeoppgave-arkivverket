package com.HansJenvild.Kodeoppgave;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Results {
    public int source_id;
    public String title;



    @Override
    public String toString() {
        return "Quote{" +
                "type='" + source_id + '\'' +
                ", value=" + title +
                '}';
    }
}
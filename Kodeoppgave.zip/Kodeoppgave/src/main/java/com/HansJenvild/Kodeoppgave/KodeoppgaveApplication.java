package com.HansJenvild.Kodeoppgave;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

@SpringBootApplication
public class KodeoppgaveApplication {
	private String url = "https://media.digitalarkivet.no/api/v1/db/browse?tags%5B%5D=373";

	private static final Logger log = LoggerFactory.getLogger(KodeoppgaveApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(KodeoppgaveApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(new MediaType[] { MediaType.APPLICATION_JSON }));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("auth-token", "9189f9c0-e5cd-4fcf-b8fd-ae864c284ec1");
		HttpEntity request = new HttpEntity(headers);
		ResponseEntity<Results> quote = restTemplate.exchange(url, HttpMethod.GET, request, Results.class);

		System.out.println(quote);

		log.info(quote.toString());

		return args -> {

		};
	}
}
package com.HansJenvild.Kodeoppgave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KodeoppgaveApplicationTests {

	@Test
	void contextLoads() {
	}

}
